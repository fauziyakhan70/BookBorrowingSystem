import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  getUser(userId : number) : Observable<any> {
    const url = `https://localhost:44380/api/User?id=${userId}`;
    return this.http.get<any>(url).pipe(
      tap((res) => {
      })
    );
  }

}

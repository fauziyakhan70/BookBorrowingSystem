import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent } from './book-dashboard/book-dashboard.component';
import { LoginComponent } from './login/login.component';
import { AddBookComponent } from './add-book/add-book.component';
import { ViewBookComponent } from './viewbook/viewbook.component';
import { BorrowedBooksComponent } from './borrowed-books/borrowed-books.component';
import { LentBooksComponent } from './lent-books/lent-books.component';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: '',
    component: DashboardComponent
  },
  {
    path: 'add-book',
    component: AddBookComponent
  },
  {
    path: 'viewbook/:id', 
    component: ViewBookComponent
  },
  {
    path: 'borrowed-books',
    component: BorrowedBooksComponent
  },
  {
    path: 'lent-books',
    component: LentBooksComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

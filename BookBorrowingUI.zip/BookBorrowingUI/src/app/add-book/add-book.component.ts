import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AddBookService } from '../add-book.service';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.scss']
})
export class AddBookComponent {
  addBookForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private addbookService: AddBookService,
    private router: Router,
    private loginService: LoginService
  ) {
    this.addBookForm = fb.group({
      name: ['', Validators.required],
      author: ['', Validators.required],
      genre: ['', Validators.required],
      description: ['', Validators.required],
      rating: ['', Validators.required],
      is_Book_Available:[true],
      Lent_By_UserId: [this.loginService.getUser()]
    });
  }

  addBook() {
    if (this.addBookForm.valid) {
      const bookData = this.addBookForm.value;
      
      this.addbookService.addBook(bookData).subscribe(
        () => {
          this.router.navigate(['/']);
        },
        error => {
          console.error('Error adding book:', error);
        }
      );
    }
  }

  getNameErrors() {
    if (this.Name?.invalid) return 'Name is required!';
    return '';
  }

  getAuthorErrors() {
    if (this.Author?.invalid) return 'Author is required!';
    return '';
  }

  getGenreErrors() {
    if (this.Genre?.invalid) return 'Genre is required!';
    return '';
  }

  getDescriptionErrors() {
    if (this.Description?.invalid) return 'Description is required!';
    return '';
  }

  getRatingErrors() {
    if (this.Rating?.invalid) return 'Rating is required!';
    return '';
  }

  getLentByIdErrors() {
    if (this.Lent_By_UserId?.invalid) return 'Lent By User ID is required!';
    return '';
  }

  // Convenience getters for form controls
  get Name() {
    return this.addBookForm.get('name');
  }

  get Author() {
    return this.addBookForm.get('author');
  }

  get Genre() {
    return this.addBookForm.get('genre');
  }

  get Description() {
    return this.addBookForm.get('description');
  }

  get Rating() {
    return this.addBookForm.get('rating');
  }

  get Lent_By_UserId() {
    return this.addBookForm.get('Lent_By_UserId');
  }
}

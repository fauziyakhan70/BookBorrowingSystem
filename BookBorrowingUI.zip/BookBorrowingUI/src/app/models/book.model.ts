// book.model.ts

export interface Book {
    name: string;
    author: string;
    genre: string;
    description: string;
    rating: number;
    Lent_By_UserId: number;
    
  }
  
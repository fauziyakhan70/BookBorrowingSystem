// borrow.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BorrowService {
  private apiUrl = 'https://localhost:44380/api/Home/borrow';

  constructor(private http: HttpClient) {}

  borrowBook(bookId: number,userId:number): Observable<any> {
    const url = `${this.apiUrl}/${bookId}/${userId}`;
    return this.http.put<any>(url, {});
  }
}

import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './book-dashboard.component.html',
  styleUrls: ['./book-dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  bookDetails: any;
  filteredBooks: any;
  isLoggedIn: boolean = false;
  nameFilter: string = '';
  authorFilter: string = '';
  genreFilter: string = '';

  constructor(
    private bookService: BookService,
    private loginService: LoginService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.isLoggedIn = this.loginService.isLoggedIn();
    this.fetchBookDetails();
  }

  fetchBookDetails(): void {
    this.bookService.getBooks().subscribe(
      (data) => {
        this.bookDetails = data;
        this.applyFilters();
      },
      (error) => {
        console.error('Error fetching book details:', error);
      }
    );
  }

  openAddBookForm(): void {
    if (this.isLoggedIn) {
      this.router.navigate(['/add-book']);
    } else {
      this.router.navigate(['/login']);
    }
  }

  applyFilters(): void {
    this.filteredBooks = this.bookDetails.filter((book: any) => {
      const nameMatch = book.name.toLowerCase().includes(this.nameFilter.toLowerCase());
      const authorMatch = book.author.toLowerCase().includes(this.authorFilter.toLowerCase());
      const genreMatch = book.genre.toLowerCase().includes(this.genreFilter.toLowerCase());

      return nameMatch && authorMatch && genreMatch;
    });
  }
}

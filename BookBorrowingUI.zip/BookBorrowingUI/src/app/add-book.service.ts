// add-book.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AddBookService {
  private apiUrl = 'https://localhost:44380/api/Home';

  constructor(private http: HttpClient) {}

  addBook(bookData: any): Observable<any> {
    console.log(bookData)
    return this.http.post<any>(this.apiUrl, bookData);
  }
}

import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  appName: string = 'Book Borrowing System';
  Username: string = '';
  Token: any;

  constructor(
    private loginService: LoginService,
    private userService: UserService,
    private router:Router
    ) {}

  ngOnInit(): void {
    this.getUserName();
    this.getToken();
  }

  getUserName(): void {
    const user = this.loginService.getUserName();
    this.Username = user;
  }

  getToken() : void {
    const id = this.loginService.getUser();
    this.userService.getUser(id).subscribe((data:any) => {
      this.Token = data.tokens_Available;
    });
  }

  logout(): void {
    this.loginService.logout();
    this.router.navigateByUrl('/login').then(() => window.location.reload());
  }
}

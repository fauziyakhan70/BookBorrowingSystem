import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private apiUrl = 'https://localhost:44380/api/Auth/login';

  constructor(private http: HttpClient) {}

  login(username: string, password: string): Observable<any> {
    const body = { username, password };
    return this.http.post<any>(this.apiUrl, body).pipe(tap(response => this.saveToken(response.token)));
  }

  saveToken(response:any ): void {
    localStorage.setItem('authToken', response);
  }

  getUser(): any {
    const userString = localStorage.getItem('authToken');
    if(userString){
      const data =this.decodeTokenPayload(userString);
      var userId=data?data.UserId:null;
      return userId;
    }
    return null;
  }

  getUserName(): any {
    const userString = localStorage.getItem('authToken');
    if(userString){
      const data =this.decodeTokenPayload(userString);
      var username=data?data.name:null;
      return username;
    }
    return null;
  }

  private decodeTokenPayload(token: string): any {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace('-', '+').replace('_', '/');
      return JSON.parse(window.atob(base64));
    } catch (error) {
      return null;
    }
  }

  clearUserData(): void {
    localStorage.removeItem('authToken');
  }

  isLoggedIn(): boolean {
    const authToken = localStorage.getItem('authToken');
    if(authToken){
      return true;
    }
    return false;
  }

  logout(): void {
    this.clearUserData();
  }
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../book.service';
import { BorrowService } from '../borrow.service';
import { LoginService } from '../login.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserService } from '../user.service';

@Component({
  selector: 'app-view-book',
  templateUrl: './viewbook.component.html',
  styleUrls: ['./viewbook.component.scss']
})
export class ViewBookComponent implements OnInit {
  bookId: any;
  bookDetails: any;
  lent_by_userid : any;
  token: any;

  constructor(
    private route: ActivatedRoute,
    private bookService: BookService,
    private borrowService: BorrowService,
    private loginService: LoginService,
    private snackbar: MatSnackBar,
    private router:Router,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.bookId = params.get('id');
      this.fetchBookDetails();
    });
    const userId=this.loginService.getUser();
    this.userService.getUser(userId).subscribe((data:any) => {
      this.token = data.tokens_Available;
      console.log(this.token);
    })
  }

  fetchBookDetails(): void {
    this.bookService.getBookById(this.bookId).subscribe(
      (data) => {
        this.bookDetails = data;
        console.log(this.bookDetails);
      },
      (error) => {
        console.error('Error fetching book details:', error);
      }
    );
  }



  borrowBook(): void {
    const userId=this.loginService.getUser();
    const bookId = this.bookDetails.lent_By_UserId;

    if(!this.bookDetails.is_Book_Available){
      this.snackbar.open('Book is not available to buy','close',{duration:3000})
      this.router.navigateByUrl('/');
      return;
    }

    if(userId == bookId){
      this.snackbar.open('User cannot borrow his own book','close',{duration:3000})
      return;
    }

    
    if(userId){
      if(this.token > 0){
    this.borrowService.borrowBook(this.bookId,userId).subscribe(
      () => {
        this.snackbar.open('Book Borrowed Successfully!!','close',{duration:3000})
        this.router.navigateByUrl('/').then(() => window.location.reload());
      },
      (error) => {
        console.error('Error borrowing book:', error);
      }
    );
   }
   else{
    this.snackbar.open('Not enough tokens!!','close',{duration:3000})
  }
  }else{
    this.snackbar.open('login first to borrow book','close',{duration:3000})
    this.router.navigateByUrl('/login');
   }
}
}

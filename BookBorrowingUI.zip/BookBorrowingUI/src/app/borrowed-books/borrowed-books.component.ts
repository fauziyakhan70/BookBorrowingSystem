import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { UserService } from '../user.service';
import { BookService } from '../book.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-borrowed-books',
  templateUrl: './borrowed-books.component.html',
  styleUrls: ['./borrowed-books.component.scss']
})
export class BorrowedBooksComponent implements OnInit{
  
  borrowedbooks: any[] =[];

  constructor(private loginService: LoginService, private router: Router, private userService: UserService, private bookService: BookService, private snackBar: MatSnackBar){}
  
  ngOnInit(): void {
    this.Books();
  }

  Books(){
    this.userService.getUser(this.loginService.getUser()).subscribe((data: any) => {
      
      this.borrowedbooks = data.books_Borrowed;
      
    })
  }

  Return(bookId: any){
    this.bookService.return(bookId).subscribe(() => {
      this.snackBar.open('Book Returned Successfully!!', 'close', {duration:3000})
      this.router.navigateByUrl('/').then(() => window.location.reload());
    },
    (error)=> {
      console.log(error);
    }
    );
  }
}

import { Component } from '@angular/core';
import { LoginService } from '../login.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-lent-books',
  templateUrl: './lent-books.component.html',
  styleUrls: ['./lent-books.component.scss']
})
export class LentBooksComponent {
  lentbooks: any[] =[];

  constructor(private loginService: LoginService, private userService: UserService){}
  
  ngOnInit(): void {
    this.Books();
  }

  Books(){
    this.userService.getUser(this.loginService.getUser()).subscribe((data: any) => {
      console.log(data.books_Lent);
      this.lentbooks = data.books_Lent;
      
    })
  }
}

import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  loginForm: FormGroup;
  responseMsg: string = '';

  constructor(private fb: FormBuilder, private loginservice: LoginService, private router: Router){
    this.loginForm = fb.group({
      username: fb.control('', [Validators.required]),
      password: fb.control('', [
        Validators.required,
        Validators.minLength(8),
        Validators.maxLength(15),
      ])
    })
  }

  getUsernameErrors() {
    if (this.Username.hasError('required')) return 'Username is required!';
    return '';
  }

  getPasswordErrors() {
    if (this.Password.hasError('required')) return 'Password is required!';
    if (this.Password.hasError('minlength'))
      return 'Minimum 8 characters are required!';
    if (this.Password.hasError('maxlength'))
      return 'Maximum 15 characters are required!';
    return '';
  }

  login() {
    const username = this.loginForm.get('username')?.value;
    const password = this.loginForm.get('password')?.value;

    this.loginservice.login(username, password).subscribe({
      next: (res: any) => {
        if (res.token) {
          this.router.navigateByUrl('/').then(() => window.location.reload());
        } else {
          this.responseMsg = 'Invalid Credentials!';
        }
      },
      error: (err: any) => {
        console.log('Error: ');
        console.log(err);
      },
    });
  }

  get Username(): FormControl {
    return this.loginForm.get('username') as FormControl;
  }
  
  get Password(): FormControl {
    return this.loginForm.get('password') as FormControl;
  }
}

﻿using BusinessLayer.Interfaces;
using DataAccessLayer.Data;
using Domain;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure.Internal;

namespace BookBorrowingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        private readonly IHomeControllerService _homeService;

        public HomeController(IHomeControllerService homeControllerService)
        {
            _homeService = homeControllerService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<BookModel>>> GetBooks()
        {
            var books = await _homeService.GetBooks();
            return Ok(books);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<BookModel>> GetBook(int id)
        {
            var book = await _homeService.GetBook(id);
            if (book == null)
            {
                return NotFound();
            }
            return book;
        }

        [HttpPost]
        public async Task<ActionResult<BookModel>> PostBook(BookModel book)
        {
            var newbook = await _homeService.PostBook(book);

            return Ok(book);
        }
        [HttpPut("borrow/{id}/{userId}")]
        public async Task<ActionResult<BookModel>> BorrowBook(int id, int userId)
        {
            var borrowedBook = await _homeService.BorrowBook(id, userId);
            if (borrowedBook == null)
            {
                return NotFound();
            }

            return Ok(borrowedBook);
        }

        [HttpPut("return/{bookId}")]
        public async Task<IActionResult> Book_Return(int bookId)
        {
            try
            {
                await _homeService.Book_Return(bookId);
                return Ok(); 
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}

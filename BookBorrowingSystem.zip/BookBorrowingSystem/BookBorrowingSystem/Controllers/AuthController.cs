﻿using BusinessLayer.Interfaces;
using DataAccessLayer.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Shared;

namespace BookBorrowingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] loginDto loginModel)
        {
            var user = await _authService.AuthenticateUserAsync(loginModel);

            if (user == null)
                return Unauthorized(new {Message="Invalid Credentials"});

             
            var token=_authService.GenerateJwtToken(user);
            return Ok(new { Token = token });
        }
    }
}

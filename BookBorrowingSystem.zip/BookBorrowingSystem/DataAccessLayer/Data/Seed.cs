﻿using Domain;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Data
{
    public class Seed
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var Scope = serviceProvider.CreateScope())
            {
                var context = Scope.ServiceProvider.GetRequiredService<BookDBContext>();
                if (context.Books.Any() || context.Users.Any()) {
                    return;

                }
                var users = new[]
                {
                new UserModel
                {
                    Name = "User A",
                    UserName = "UserA",
                    Password = "User@#123",
                    Tokens_Available = 100,
                },
                new UserModel
                {
                    Name = "User B",
                    UserName = "UserB",
                    Password = "User@#123",
                    Tokens_Available = 0,
                },
                new UserModel
                {
                    Name = "User C",
                    UserName = "UserC",
                    Password = "User@#123",
                    Tokens_Available = 0,
                },
                new UserModel
                {
                    Name = "User D",
                    UserName = "UserD",
                    Password = "User@#123",
                    Tokens_Available = 0,
                },
                };
                context.Users.AddRange(users);
                context.SaveChanges();

                var books = new[]
               {
                new BookModel
                {
                    Name = "One piece",
                    Rating=5,
                    Author = "Eiichiro Oda",
                    Genre = "Anime",
                    Description = "ONE PIECE is a legendary high-seas quest unlike any other.",
                    Is_Book_Available= false,
                    Lent_By_UserId= users[0].UserId,
                    Borrowed_By_UserId=users[1].UserId,
                },
                new BookModel
                {
                    Name = "Naruto",
                    Rating=5,
                    Author = "Masashi Kishimoto",
                    Genre = "Anime",
                    Description = "Summary-Naruto is a ninja-in-training whose wild antics amuse his teammates.",
                    Is_Book_Available= true,
                    Lent_By_UserId= users[1].UserId,
                    Borrowed_By_UserId=null,
                },
                new BookModel
                {
                    Name = "Attack on Titan",
                    Rating=5,
                    Author = "Hajime Isayama",
                    Genre = "Anime",
                    Description = "Set in a post-apocalyptic world where the remains of humanity live behind walls protecting them from giant humanoid Titans,",
                    Is_Book_Available= true,
                    Lent_By_UserId= users[2].UserId,
                    Borrowed_By_UserId=null,
                },

                };
                context.Books.AddRange(books);
                context.SaveChanges();
            }   }
    }
}

﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Interfaces
{
    public interface IBookRepository
    {
        Task<IEnumerable<BookModel>> GetBooks();
        Task<BookModel> GetBookById(int id);
        Task <BookModel> AddBook(BookModel book);
        Task<BookModel> BorrowBook(int bookId, int userId);
        Task Return(int id);
    }
}

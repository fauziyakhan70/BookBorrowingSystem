﻿using DataAccessLayer.Data;
using DataAccessLayer.Interfaces;
using Domain;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace DataAccessLayer.Repositories
{
    public class BookRepository : IBookRepository
    {
        private readonly BookDBContext _context;
        public BookRepository(BookDBContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<BookModel>> GetBooks()
        {
            return await _context.Books.ToListAsync();
        }

        public async Task<BookModel> GetBookById(int id)
        {
            return await _context.Books.FindAsync(id);
        }

        public async Task<BookModel> AddBook(BookModel book)
        {
            _context.Books.Add(book);
            await _context.SaveChangesAsync();
            return book;
        }

        public async Task<BookModel> BorrowBook(int bookId, int userId)
        {
            var book = await _context.Books.FindAsync(bookId);

            if (book != null && book.Is_Book_Available && await UserHasToken(userId))
            {
                book.Is_Book_Available = false;
                book.Borrowed_By_UserId = userId;
                var lenderId = book.Lent_By_UserId;

                var borrower = await _context.Users.FindAsync(userId);
                borrower.Tokens_Available--;

                var lender = await _context.Users.FindAsync(lenderId);
                lender.Tokens_Available++;

                await _context.SaveChangesAsync();
            }

            return book;
        }

        private async Task<bool> UserHasToken(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            return user != null && user.Tokens_Available > 0;
        }

        public async Task Return(int id)
        {
            var book = await _context.Books.FindAsync(id);
            book.Borrowed_By_UserId = null;
            book.Is_Book_Available = true;
            _context.SaveChanges();
        }
    }
}

﻿using DataAccessLayer.Data;
using DataAccessLayer.Interfaces;
using Domain;
using Microsoft.EntityFrameworkCore;
using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DataAccessLayer.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly BookDBContext _context;
        public UserRepository(BookDBContext context)
        {
            _context=context;
        }

        public async Task<UserModel> GetUserById(int id)
        {
            return await _context.Users.Where(u => u.UserId == id).Select(u=>new UserModel { UserId =u.UserId, Name=u.Name , UserName=u.UserName , Password=null , Tokens_Available = u.Tokens_Available , Books_Borrowed=u.Books_Borrowed , Books_Lent= u.Books_Lent }).FirstOrDefaultAsync();
        }

        public  Task <UserModel> userLogin(loginDto login)
        {
            var user= _context.Users.SingleOrDefault(u => u.UserName == login.Username && u.Password == login.Password);
            return Task.FromResult(user);
        }
    }
}

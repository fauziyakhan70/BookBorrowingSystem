﻿using BusinessLayer.Interfaces;
using DataAccessLayer.Data;
using DataAccessLayer.Interfaces;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Services
{
    public class HomeControllerService : IHomeControllerService
    {
        private readonly IBookRepository _bookRepository; 

        public HomeControllerService(IBookRepository boookRepository)
        {
            _bookRepository = boookRepository;  
        }
        public async Task<BookModel> GetBook(int id)
        {
            return await _bookRepository.GetBookById(id);
        }

        public async Task<IEnumerable<BookModel>> GetBooks()
        {
            return await _bookRepository.GetBooks();
        }

        public async Task<BookModel> PostBook(BookModel book)
        {
            var newbook = await _bookRepository.AddBook(book);
            return book;
        }
        public async Task<BookModel> BorrowBook(int bookId, int userId)
        {
            return await _bookRepository.BorrowBook(bookId, userId);
        }

        public async Task Book_Return(int bookId)
        {
            await _bookRepository.Return(bookId);
        }
    }
}

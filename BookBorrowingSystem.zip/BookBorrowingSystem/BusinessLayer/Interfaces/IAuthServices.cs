﻿using Domain;
using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces
{
    public interface IAuthService
    {
        string GenerateJwtToken(UserModel user);
        Task<UserModel> AuthenticateUserAsync(loginDto loginModel);
    }
}

﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces
{
    public interface IHomeControllerService
    {
        Task<IEnumerable<BookModel>> GetBooks();

        Task<BookModel> GetBook(int id);

        Task<BookModel> PostBook(BookModel book);
        Task<BookModel> BorrowBook(int bookId, int userId);

        Task Book_Return(int bookId);
    }
}

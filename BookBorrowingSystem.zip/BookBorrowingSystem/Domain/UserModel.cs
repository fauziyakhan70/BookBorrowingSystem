﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class UserModel
    {
        [Key]
        [Required]
        public int UserId { get; set; }  // User ID (Unique)
       
        public string Name { get; set; }
        public string UserName { get; set; }
    
        public string Password { get; set; }

        public int Tokens_Available { get; set; }
        public ICollection<BookModel> ?Books_Borrowed { get; set;}
        public ICollection<BookModel> Books_Lent { get; set; }

    }
}

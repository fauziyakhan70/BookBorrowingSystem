﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class BookModel
    {
        [Key]
        [Required]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Author { get; set; }
        public string Genre { get; set; }
        public string Description { get; set; }
        public bool Is_Book_Available { get; set; }
        [ForeignKey("Lender")]

        [Range(1, 5)] 
        public int Rating { get; set; }
        public int Lent_By_UserId { get; set; }
        [ForeignKey("Borrower")]
        public int? Borrowed_By_UserId { get; set; }
       
    }
}
